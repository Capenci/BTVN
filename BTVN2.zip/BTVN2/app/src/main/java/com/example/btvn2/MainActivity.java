package com.example.btvn2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    List<StudentModel> students;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        students=new ArrayList<>();
        SQLiteDatabase db=null;
        try{
            String pathdb=getDatabasePath("studentDB.db").getPath();
           db=SQLiteDatabase.openOrCreateDatabase(pathdb,null) ;
        } catch (SQLiteException ex) {
            Log.e(null,ex.getMessage());
        }
        //creat table
        if(!isTableExist(db,"studenttable")){
            db.execSQL("create table studenttable(" +
                    "mssv text PRIMARY KEY," +
                    "name text," +
                    "email text," +
                    "addr text," +
                    "dob text)");
        }else{
            Cursor cursor=db.rawQuery("SELECT * FROM studenttable",null);
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                String mssv= cursor.getString(0);
                String  name=cursor.getString(1);
                String email= cursor.getString(2);
                String  addr=cursor.getString(3);
                String dob= cursor.getString(4);
                students.add(new StudentModel(name,mssv,email,addr,dob));
                cursor.moveToNext();
            }cursor.close();
        }
        //Read database

        final RecyclerView recyclerView=findViewById(R.id.recycleview);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        final StudentAddapter studentAddapter=new StudentAddapter(students);
        recyclerView.setAdapter(studentAddapter);
        //Button
        findViewById(R.id.btn_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,AddActivity.class);
                startActivity(intent);
            }
        });
        EditText search=findViewById(R.id.edt_search);
        final String temp=search.getText().toString();
        List<StudentModel> listSearch=null;
        listSearch=new ArrayList<>();
        final SQLiteDatabase finalDb = db;

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor searchCursor;
                if(temp.charAt(0)>=0 && temp.charAt(0)<=9){
                     searchCursor= finalDb.rawQuery("SELECT * FROM studenttable WHERE mssv="+temp,null);

                }else{
                    searchCursor= finalDb.rawQuery("SELECT * FROM studenttable WHERE name="+temp,null);
                }
                searchCursor.moveToFirst();
                while(!searchCursor.isAfterLast()){
                    String mssv= searchCursor.getString(0);
                    String  name=searchCursor.getString(1);
                    String email= searchCursor.getString(2);
                    String  addr=searchCursor.getString(3);
                    String dob= searchCursor.getString(4);
                    students.add(new StudentModel(name,mssv,email,addr,dob));
                    searchCursor.moveToNext();
                }searchCursor.close();
            }
        });
    }
    boolean isTableExist(SQLiteDatabase db, String table) {
        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", new String[]{table});
        boolean tableExist = (cursor.getCount() != 0);
        cursor.close();
        return tableExist;
    }
}

