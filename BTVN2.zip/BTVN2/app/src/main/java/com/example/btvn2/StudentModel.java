package com.example.btvn2;

public class StudentModel {
    String name;
    String mssv;
    String email;
    String addr;
    String dob;
    public StudentModel(String name,String mssv,String email,String addr,String dob){
        this.name=name;
        this.mssv=mssv;
        this.email=email;
        this.addr=addr;
        this.dob=dob;
    }
    public String getName(){return name;}
    public String getMssv(){return mssv;}
    public String getEmail(){return email;}
    public String getAddr(){return addr;}
    public String getDob(){return dob;}
}
