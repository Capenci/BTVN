package com.example.btvn2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {
    //Return mainactivity
    public void back(){
        Intent intent=new Intent(AddActivity.this,MainActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        final EditText edtname=findViewById(R.id.edt_name);
        final EditText edtmssv=findViewById(R.id.edt_MSSV);
        final EditText edtemail=findViewById(R.id.edt_email);
        final EditText edtaddr=findViewById(R.id.edt_addr);
        final EditText edtdob=findViewById(R.id.edt_dob);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        findViewById(R.id.btn_addSt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add student
                SQLiteDatabase db=null;
                try{
                    String pathdb=getDatabasePath("studentDB.db").getPath();
                    db= SQLiteDatabase.openOrCreateDatabase(pathdb,null) ;
                } catch (SQLiteException ex) {
                    Log.e(null,ex.getMessage());
                }
                db.execSQL("INSERT INTO studenttable(mssv,name,email,addr,dob) VALUES("+ edtmssv.getText().toString() +"," + edtname.getText().toString() +"," + edtemail.getText().toString() +"," + edtaddr.getText().toString() +"," + edtdob.getText().toString() +")");
                db.setTransactionSuccessful();
                edtname.setHint("Enter name");
                edtmssv.setHint("Enter MSSV");
                edtaddr.setHint("Enter Addr");
                edtemail.setHint("Enter Email");
                edtdob.setHint("Enter DoB");
            }
        });
    }
}
