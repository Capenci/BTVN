package com.example.btvn2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAddapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    List<StudentModel> students;
    public StudentAddapter(List<StudentModel> students){this.students=students;}
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.student,parent,false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        StudentViewHolder viewHolder=(StudentViewHolder) holder;
        StudentModel student=students.get(position);
        viewHolder.txtName.setText(student.getName());
        viewHolder.txtMSSV.setText(student.getMssv());
        viewHolder.txtEmail.setText(student.getEmail());
        viewHolder.txtAddr.setText(student.getAddr());
        viewHolder.txtDoB.setText(student.getDob());
    }

    @Override
    public int getItemCount() {
        return students.size();
    }
    class StudentViewHolder extends RecyclerView.ViewHolder{
        TextView txtName;
        TextView txtMSSV;
        TextView txtEmail;
        TextView txtAddr;
        TextView txtDoB;
        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName=itemView.findViewById(R.id.name);
            txtMSSV=itemView.findViewById(R.id.MSSV);
            txtEmail=itemView.findViewById(R.id.email);
            txtAddr=itemView.findViewById(R.id.addr);
            txtDoB=itemView.findViewById(R.id.dob);
        }
    }
}
